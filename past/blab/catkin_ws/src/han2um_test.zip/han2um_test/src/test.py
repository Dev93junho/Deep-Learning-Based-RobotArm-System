import math as mt


theta=1.5

def angle_filter(theta):
    if not 0<=theta<=mt.pi/2:
        print('aaa') 


angle_filter(theta) 